#Tener instalado R y RStudio
#Haber realizado el prework y estudiado los ejemplos de la sesión.
#Desarrollo
#Inspecciona el DataSet iris_meaniris` disponible directamente en R. 
#Identifica las variables que contiene y su tipo, asegúrate de que no
#hayan datos faltantes y que los datos se encuentran listos para usarse.

df <- iris
head(df)
str(df)
dim(df)
View(df)
#'data.frame':	150 obs. of  5 variables:
#$ Sepal.Length: num  5.1 4.9 4.7 4.6 5 5.4 4.6 5 4.4 4.9 ...
#$ Sepal.Width : num  3.5 3 3.2 3.1 3.6 3.9 3.4 3.4 2.9 3.1 ...
#$ Petal.Length: num  1.4 1.4 1.3 1.5 1.4 1.7 1.4 1.5 1.4 1.5 ...
#$ Petal.Width : num  0.2 0.2 0.2 0.2 0.2 0.4 0.3 0.2 0.2 0.1 ...
#$ Species     : Factor w/ 3 levels "setosa","versicolor","virginica": 1 1 1 1 1 1 1 1 1 1 ...

#Crea una gráfica de puntos que contenga Sepal.Lenght en el eje horizontal, 
#Sepal.Width en el eje vertical, que identifique Species por color y que el tamaño de la 
#figura está representado por Petal.Width. Asegúrate de que la geometría 
#contenga shape = 10 y alpha = 0.5.
library(ggplot2) 

graph <- ggplot(df, aes(x=Sepal.Length, y = Sepal.Width, color = Species, size = Petal.Width)) + 
  geom_point(shape=10, alpha=0.5)

graph


#Crea una tabla llamada iris_mean que contenga el promedio 
#de todas las variables agrupadas por Species.
library(dplyr)

iris.mean <- df %>% group_by(Species) %>%
             summarize_all(mean)
  
iris.mean
#Con esta tabla, agrega a tu gráfica anterior otra 
#geometría de puntos para agregar los promedios en la visualización. 
#Asegúrate que el primer argumento de la geometría sea el nombre de tu 
#tabla y que los parámetros sean shape = 23, size = 4, fill = "black" 
#y stroke = 2. También agrega etiquetas, temas y los cambios 
#necesarios para mejorar tu visualización.
graph <- graph + 
  geom_point(data=iris.mean,shape=23,size = 4, fill = "black", stroke = 2)+
  labs(title = "Iris dataset",
       x = "Sepal Length",
       y = "Sepal Width") + 
  scale_size("Petal Width")+
  theme_classic()

graph

