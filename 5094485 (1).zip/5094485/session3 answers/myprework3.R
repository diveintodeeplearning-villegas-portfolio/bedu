var <- read.csv("https://raw.githubusercontent.com/beduExpert/Programacion-R-Santander-2022/main/Sesion-03/Data/variables.csv")
str(var)
summary(var)

var$SEXO <- factor(var$SEXO)
var$ESTUDIOS <- factor(var$ESTUDIOS, levels = c("Primaria", "Bachillerato", "Licenciatura", "Maestria"), ordered = TRUE)
var$NIVEL_SOCIOECO <- factor(var$NIVEL_SOCIOECO, levels = c("Bajo", "Medio", "Alto"), ordered = TRUE)
var$MEDIO_CONTACTO <- factor(var$MEDIO_CONTACTO)
var$ACTIVO <- factor(var$ACTIVO, labels = c("No", "Si"))

summary(var)

freq <- table(var$ESTUDIOS)
transform(freq, 
          rel.freq=prop.table(Freq))

library(ggplot2)
ggplot(var, aes(x = ESTUDIOS)) + geom_bar()

k = ceiling(sqrt(length(var$INGRESO)))
ac = (max(var$INGRESO)-min(var$INGRESO))/k

bins <- seq(min(var$INGRESO), max(var$INGRESO), by = ac)
ingreso.clases <- cut(var$INGRESO, breaks = bins, include.lowest=TRUE, dig.lab = 8)

dist.freq <- table(ingreso.clases)
transform(dist.freq, 
          rel.freq=prop.table(Freq), 
          cum.freq=cumsum(prop.table(Freq)))



df <- read.csv("https://raw.githubusercontent.com/beduExpert/Programacion-R-Santander-2022/main/Sesion-03/Data/telecom_service.csv")
summary(df)

mean(df$total_day_calls)
mean(df$total_day_calls, trim = 0.20)

median(df$total_day_calls)

#mode(df$total_day_calls)
frecuencias <- data.frame(table(df$total_day_calls))
moda <- frecuencias[which.max(frecuencias$Freq),1]
moda


var(df$total_day_calls)
sd(df$total_day_calls)

IQR(df$total_day_calls) #Dispersión alrededor a la mediana
iqr = quantile(df$total_day_calls, probs = 0.75) - quantile(df$total_day_calls, probs = 0.25)
iqr


cuartiles <- quantile(df$total_day_calls, probs = c(0.25, 0.50, 0.75))
cuartiles

deciles <-quantile(df$total_day_calls, probs = c(0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9))
deciles

percentiles <- quantile(df$total_day_calls, probs = seq(0.01,0.99, by=0.01))
percentiles


d <- read.csv("https://raw.githubusercontent.com/beduExpert/Programacion-R-Santander-2022/main/Sesion-03/Data/distribuciones.csv")

install.packages("moments") 
library(moments)
skewness(d$rs) #s > 0 Sesgo a la derecha
skewness(d$sim) #s = 0 Simétrica
skewness(d$ls) #s < 0 Sesgo a la izquierda

kurtosis(d$rs) #Leptocúrtica k > 3
kurtosis(d$sim) #Mesocúrtica k = 3
kurtosis(d$ls) #Platocúrtica k < 3

hist(var$INGRESO, breaks = bins, main = "Histograma Ingreso")

my_hist <- hist(var$INGRESO, breaks = bins, main = "Histograma", xlab = "Ingreso")
my_hist$counts <- cumsum(my_hist$counts)
plot(my_hist, main = "Histograma acumulado", xlab = "Ingreso")


ggplot(var, aes(INGRESO)) +
  geom_histogram(bins = 4) + 
  labs(title = "Histograma", 
       x = "Ingreso",
       y = "Frequency") + 
  theme_classic()

ggplot(var, aes(INGRESO)) +
  geom_histogram(aes(y = cumsum(..count..)), bins = 4) + 
  labs(title = "Histograma acumulado", 
       x = "Ingreso",
       y = "Frequency") + 
  theme_classic()

d <- read.csv("https://raw.githubusercontent.com/beduExpert/Programacion-R-Santander-2022/main/Sesion-03/Data/distribuciones.csv")
d
install.packages("modeest")
library(modeest)
Mode <- function(x) {
  d <- density(x)
  d$x[which.max(d$y)]
}

hist(d$sim, main = "Distribución simétrica")
Mode(d$sim)[1]; median(d$sim); mean(d$sim)

hist(d$rs, main = "Distribución con sesgo a la derecha")
Mode(d$rs)[1]; median(d$rs); mean(d$rs)

hist(d$ls, main = "Distribución con sesgo a la izquierda")
Mode(d$ls)[1]; median(d$ls); mean(d$ls)

boxplot(d$sim, horizontal = TRUE)
boxplot(d$rs, horizontal = TRUE)
boxplot(d$ls, horizontal = TRUE)


df <- diamonds
cor(df$table, df$price)
install.packages('dplyr') 
library(dplyr)

df.select <- select(df, price, carat, depth, table)
corr_matrix <- round(cor(df.select),4)
corr_matrix



ggplot(df, aes(x=carat, y=price)) + 
  geom_point() +                                     
  stat_smooth(method = "lm",
              formula = y ~ x,
              geom = "smooth") +
  labs(title = "Gráfica de dispersión", 
       x = "Carat",
       y = "Price") + 
  theme_classic()
