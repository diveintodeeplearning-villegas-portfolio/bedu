#Utilizando el dataframe boxp.csv realiza el siguiente análisis descriptivo. No olvides excluir los missing values y transformar las variables a su tipo y escala correspondiente.

#"1) Calcula e interpreta las medidas de tendencia central de la variable Mediciones


df <- read.table(file = 'https://raw.githubusercontent.com/beduExpert/Programacion-R-Santander-2022/main/Sesion-03/Data/boxp.csv',
                     header = TRUE,
                     sep = ',',na.strings=c(NA, "NA", " NA"))
head(df)
df.clean <- na.omit(df)
head(df.clean)
dim(df.clean)

media <- mean(df.clean$Mediciones)
media
mediana <- median(df.clean$Mediciones)
mediana
moda <- Mode(df.clean$Mediciones)
moda
#los datos tienen un sasgo a la derecha

#Con base en tu resultado anteior, ¿qué se puede concluir respecto al sesgo de Mediciones?
#los datos tienen un sasgo a la derecha
skewness(df.clean$Mediciones) #s > 0 Sesgo a la derecha
kurtosis(df.clean$Mediciones) #Leptocúrtica k > 3

#Calcula e interpreta la desviación estándar y los cuartiles de la distribución de Mediciones
des.std <- sd(df.clean$Mediciones)
des.std
cuartiles <- quantile(df.clean$Mediciones, probs = c(0.25, 0.50, 0.75))
cuartiles
#los datos tienen mucha desviacion

#Con ggplot, realiza un histograma separando la distribución de Mediciones por Categoría ¿Consideras que sólo una categoría está generando el sesgo?

medc1 <- df.clean$Mediciones[df.clean$Categoria == 'C1']
medc2 <- df.clean$Mediciones[df.clean$Categoria == 'C2']
medc3 <- df.clean$Mediciones[df.clean$Categoria == 'C3']


k = ceiling(sqrt(length(df.clean$Mediciones)))
ac = (max(df.clean$Mediciones)-min(df.clean$Mediciones))/k
bins <- seq(min(df.clean$Mediciones), max(df.clean$Mediciones), by = ac)
hist(df.clean$Mediciones, breaks = bins, main = "Histograma de mediciones")

my_hist <- hist(df.clean$Mediciones, breaks = bins, main = "Histograma", xlab = "Price")
my_hist$counts <- cumsum(my_hist$counts)
plot(my_hist, main = "Histograma acumulado", xlab = "Mediciones")

my_hist1 <- hist(medc1, breaks = bins, main = "Histograma", xlab = "Mediciones C1")
my_hist2 <- hist(medc2, breaks = bins, main = "Histograma", xlab = "Mediciones C2")
my_hist3 <- hist(medc3, breaks = bins, main = "Histograma", xlab = "Mediciones C3")

#todas las mediciones tienen sesgo a la derecha

#Con ggplot, realiza un boxplot separando la distribución de Mediciones por Categoría y por Grupo dentro de cada categoría. ¿Consideras que hay diferencias entre categorías? ¿Los grupos al interior de cada categoría podrían estar generando el sesgo?
medc1g0 <- df.clean$Mediciones[df.clean$Categoria == 'C1' & df.clean$Grupo == 0 ]
medc1g1 <- df.clean$Mediciones[df.clean$Categoria == 'C1' & df.clean$Grupo == 1 ]
medc2g0 <- df.clean$Mediciones[df.clean$Categoria == 'C2' & df.clean$Grupo == 0]
medc2g1 <- df.clean$Mediciones[df.clean$Categoria == 'C2' & df.clean$Grupo == 1]
medc3g0 <- df.clean$Mediciones[df.clean$Categoria == 'C3'& df.clean$Grupo == 0]
medc3g1 <- df.clean$Mediciones[df.clean$Categoria == 'C3'& df.clean$Grupo == 1]

boxplot(df.clean$Mediciones, horizontal = TRUE)
boxplot(medc1g0, horizontal = TRUE)
boxplot(medc1g1, horizontal = TRUE)
boxplot(medc2g0, horizontal = TRUE)
boxplot(medc2g1, horizontal = TRUE)
boxplot(medc3g0, horizontal = TRUE)
boxplot(medc3g1, horizontal = TRUE)
#todos los datos tienen sesgo a la derecha sin importar la categoria o el grupo