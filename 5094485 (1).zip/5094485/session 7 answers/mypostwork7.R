#OBJETIVO
#Estimar modelos ARIMA y realizar predicciones
#DESARROLLO
#Utilizando el siguiente vector numérico, realiza lo que se indica:
url = "https://raw.githubusercontent.com/beduExpert/Programacion-R-Santander-2022/main/Sesion-07/Data/global.txt"
Global <- scan(url, sep="")
head(Global)
#Crea una objeto de serie de tiempo con los datos de Global. La serie debe ser mensual comenzado en Enero de 1856
global.ts <- ts(Global,start=c(1856,1),frequency=12, )
#Realiza una gráfica de la serie de tiempo anteriorde 2005")
plot(global.ts, 
     main = "Datos de Global", 
     xlab = "Tiempo",
     sub = "Grafica de serie de tiempo: Enero de 1856 - Diciembre de 2005")
#Ahora realiza una gráfica de la serie de tiempo anterior, transformando a la primera diferencia:
plot(diff(global.ts), 
     main = "Primera diferencia de: Datos de Global", 
     xlab = "Tiempo",
     sub = "Grafica de de primera diferencia: Enero de 1856 - Diciembre de 2005")

#¿Consideras que la serie es estacionaria en niveles o en primera diferencia?
acf(global.ts)
pacf(global.ts)
#En la ACF tiene una fuerte autocorrelacion. En la PACF tiene como dos rezagos significativos.



acf(diff(global.ts))
pacf(diff(global.ts))

"Como se observa, la función de ACP de global.ts muestra rezagos significativos parciales.
La función de AC muestra una serie de tiempo totalmente correlacionada. Ahora vamos a ver si la primera diferencia
es posible convertirlas en estacionarias. 
En primera diferencia la serie es estacionaria.
"
#Con base en tu respuesta anterior, obten las funciones de autocorrelación y autocorrelación parcial?

acf(diff(global.ts))
pacf(diff(global.ts))


