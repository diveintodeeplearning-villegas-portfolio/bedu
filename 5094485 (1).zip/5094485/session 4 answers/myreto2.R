#Un banco recibe, en promedio, 6 cheques sin fondo por día.

set.seed(0202)
#a) Grafica la función de distribución de la variable aleatoria. (Asume que se obtienen 10,000 muestras)

#dpois(x, lambda, log = FALSE)
#ppois(q, lambda, lower.tail = TRUE, log.p = FALSE)
#qpois(p, lambda, lower.tail = TRUE, log.p = FALSE)
#rpois(n, lambda)
lambda <- 6
n <- 10000

poisson <- rpois(n, lambda)
barplot(table(poisson)/length(poisson),
        main = "Distribución de Poisson", 
        xlab = "X=x")

#b) ¿Cuál es la probabilidad de que reciba 4 cheques sin fondo en un dia

dpois(4, lambda, log = FALSE) #0.13
#c) ¿Cuál es la probabilidad de que reciba más de 8 cheques sin fondo?
1- ppois(8, lambda, lower.tail = TRUE, log.p = FALSE) #0.15
#  d) ¿Cuál es la probabilidad de que reciba entre 4 y 10 cheques sin fondo?
ppois(10, lambda, lower.tail = TRUE, log.p = FALSE) - ppois(4, lambda, lower.tail = TRUE, log.p = FALSE) #0.67
#  e) ¿Cuál es la probabilidad de que tengan que pasar 5 horas o menos hasta que se presente el siguiente cheque sin fondos?
pexp(q = 5, rate = 6/24, lower.tail = FALSE) #0.28
#  f) ¿Cuál es la probabilidad de que tengan que pasar entre 2 y 4 hasta que se presente el siguiente cheque sin fondos?
pexp(q = 4, rate = 6/24, lower.tail = TRUE) - pexp(q = 2, rate = 6/24, lower.tail = TRUE) #0.23
#  g) Realiza la gráfica de distribución de probabilidad de la variable aleatoria anterior
curve(dexp(x, rate =6/24), from=0, to=24, 
      col='blue', main = "Distribución exponencial",
      ylab = "f(x)", xlab = "Tiempo entre eventos")
