#Una maquina de ensamblaje, tiene una probabilidad de 0.15 de ensamblar de forma defectuosa una una unidad. Si la producción de una unidad es totaltamente independiente de las demás y al día se producen 10 unidades:
  
set.seed(0202)
p <- 0.15
size <- 10

#a) Grafica la función de distribución de la variable aleatoria. (Asume que se obtienen 10,000 muestras)
n <- 10000

binom <- rbinom(n = n, size = size, prob = p)

barplot(table(binom)/length(binom),
        main = "Distribución Binomial", 
        xlab = "# de defectosos por lote")

#b) ¿Cuál es la probabilidad de que se produzcan dos unidades defectuosas?
dbinom(x = 2, size = size, prob = p) #0.27
  
#c) ¿Cuál es la probabilidad de que a lo mucho 4 unidades sean defectuosas?
pbinom(q = 4, size = size, prob = p, lower.tail = TRUE) #P(X<=x)
#0.99

#d) ¿Cuál es la probabiliad de que por lo menos tres unidades se encuentren defectuosa?
pbinom(q = 2, size = size, prob = p, lower.tail = FALSE) #P(X<=x)
#0.17

#e) ¿Cuál es la probabilidad de que entre 2 y 4 unidades se encuentren defectuosas?
pbinom(q = 4, size = size, prob = p, lower.tail = TRUE) - pbinom(q = 2, size = size, prob = p, lower.tail = TRUE) #P(X<=x)
# P(X<=b) - P(X<=a) = P(a < X <= b) 0.16

#f) ¿Cuál es el número esperado de unidades defectuosas? ¿Con qué variación?
mean(binom) #1.49
sd(binom) #1.13
