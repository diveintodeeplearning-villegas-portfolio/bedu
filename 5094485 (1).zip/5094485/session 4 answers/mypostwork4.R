'Utilizando la variable total_intl_charge de la base de datos telecom_service.csv '
'de la sesión 3, realiza un análisis probabilístico. Para ello, debes determinar la'
'función de distribución de probabilidad que más se acerque el comportamiento de los datos. '
'Hint: Puedes apoyarte de medidas descriptivas o técnicas de visualización.'
library(DescTools)
df <- read.csv("https://raw.githubusercontent.com/beduExpert/Programacion-R-Santander-2022/main/Sesion-03/Data/telecom_service.csv")
str(df)
summary(df)
head(df)
head(df$ total_intl_charge)
summary(df$ total_intl_charge)

mean(df$ total_intl_charge)
median(df$ total_intl_charge)
Mode(df$ total_intl_charge)
hist(df$ total_intl_charge,prob=T,main="Histograma total cargos internacionales")

barplot(table(df$ total_intl_charge)/length(df$ total_intl_charge), 
        main = "hist", 
        xlab = "total intl chaege",
        )
nm <- mean(df$ total_intl_charge)
sn <- sd(df$ total_intl_charg)

'Una vez que hayas seleccionado el modelo, realiza lo siguiente:'
  
'Grafica la distribución teórica de la variable aleatoria total_intl_charge'
curve(dnorm(x, mean = nm, sd = sn), from=0, to=5, 
      col='blue', main = "Densidad de Probabilidad Normal",
      ylab = "f(x)", xlab = "X")
'¿Cuál es la probabilidad de que el total de cargos internacionales sea menor a 1.85 usd?'
  
pnorm(q= 1.8, mean=nm,sd=sn)
 ' ¿Cuál es la probabilidad de que el total de cargos internacionales sea mayor a 3 usd?'
1-pnorm(q= 3, mean=nm,sd=sn)
pnorm(q= 3, mean=nm,sd=sn,lower.tail = FALSE)

  '¿Cuál es la probabilidad de que el total de cargos internacionales esté entre 2.35usd y 4.85 usd?'

  pnorm(q= 4.85, mean=nm,sd=sn)-pnorm(q= 2.35, mean=nm,sd=sn)

  
  'Con una probabilidad de 0.48, ¿cuál es el total de cargos internacionales más alto que podría esperar?'
  
  qnorm(p=0.48,mean=nm,sd=sn)
  
  '¿Cuáles son los valores del total de cargos internacionales que dejan exactamente al centro el 80% de probabilidad?'
  
  qnorm(p=0.10,mean=nm,sd=sn);qnorm(p=0.90,mean=nm,sd=sn)
  