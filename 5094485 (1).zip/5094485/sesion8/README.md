# Bienvenido a mi primer repositorio
Este es mi prepositorio de R y contiene:
- Script de R
- README 
- hola mundoo
