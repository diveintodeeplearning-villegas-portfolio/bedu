# RETO 2. MANIPULACIÓN DE DATAFRAMES CON DPLYR

#### Objetivo

- Practicar el uso de las funciones de la librería de dplyr para la manipulación y transformación de DataFrames

#### Requisitos

- Haber estudiado el Prework y trabajado con el Work

#### Desarrollo

Utilizando el DataFrame del Reto01 de esta sesión, crea una tabla que muestre sólo aquellos equipos que, en total de la liga, hayan metido más del 85% de
los goles jugando como local. Muestra sólo las variables HomeTeam y tu variable de proporción y arregla los datos de forma descendente respecto a la 
proporción de goles.
