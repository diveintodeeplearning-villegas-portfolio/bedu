"Postwork sesión 8. Análisis de la Inseguridad Alimentaria en México
OBJETIVO
Realizar un análisis estadístico completo de un caso
Publicar en un repositorio de Github el análisis y el código empleado
REQUISITOS
Haber realizado los works y postworks previos
Tener una cuenta en Github o en RStudioCloud
DESARROLLO
Un centro de salud nutricional está interesado en analizar estadísticamente y probabilísticamente los patrones de gasto en alimentos saludables y no saludables en los hogares mexicanos con base en su nivel socioeconómico, en si el hogar tiene recursos financieros extrar al ingreso y en si presenta o no inseguridad alimentaria. Además, está interesado en un modelo que le permita identificar los determinantes socioeconómicos de la inseguridad alimentaria.

La base de datos es un extracto de la Encuesta Nacional de Salud y Nutrición (2012) levantada por el Instituto Nacional de Salud Pública en México. La mayoría de las personas afirman que los hogares con menor nivel socioeconómico tienden a gastar más en productos no saludables que las personas con mayores niveles socioeconómicos y que esto, entre otros determinantes, lleva a que un hogar presente cierta inseguridad alimentaria.

La base de datos contiene las siguientes variables:

#nse5f (Nivel socieconómico del hogar): 1 Bajo, 2 Medio bajo, 3 Medio, 4 Medio alto, 5 Alto
#area (Zona geográfica): 0 Zona urbana, 1 Zona rural
#numpeho (Número de persona en el hogar)
#refin (Recursos financieros distintos al ingreso laboral): 0 no, 1 sí
#edadjef (Edad del jefe/a de familia)
#sexoje (Sexo del jefe/a de familia): 0 Hombre, 1 Mujer
#añosedu (Años de educación del jefe de familia)
#ln_als (Logarítmo natural del gasto en alimentos saludables)
#ln_alns (Logarítmo natural del gasto en alimentos no saludables)
#IA (Inseguridad alimentaria en el hogar): 0 No presenta IA, 1 Presenta IA
"
df <- read.csv("https://raw.githubusercontent.com/beduExpert/Programacion-R-Santander-2022/main/Sesion-08/Postwork/inseguridad_alimentaria_bedu.csv")

"Plantea el problema del caso
Realiza un análisis descriptivo de la información
Calcula probabilidades que nos permitan entender el problema en México
Plantea hipótesis estadísticas y concluye sobre ellas para entender el problema en México
Estima un modelo de regresión, lineal o logístico, para identificiar los determinanres de la inseguridad alimentaria en México
Escribe tu análisis en un archivo README.MD y tu código en un script de R y publica ambos en un repositorio de Github.
NOTA: Todo tu planteamiento deberá estár correctamente desarrollado y deberás analizar e interpretar todos tus resultados para poder dar una conclusión final al problema planteado."

library(dplyr)
#install.packages("DescTools")
library(DescTools)
library(ggplot2)
#install.packages("moments")
library(moments)

head(df)
summary(df)
# Limpiar base de datos
df.clean <- na.omit(df)
head(df.clean)
dim(df.clean)
dim(df)
#
summary(df.clean)

#Descripcion del Problema
" Analizar las variables: gasto de alimento saludable, gasto de alimento no saludable, nivel socioeconomico, ingresos extras, e inseguridad alimentaria.
Ademas, de identificar las variables relacionadas con la inseguridad alimentaria y crear un modelo predictivo de la inseguridad alimentaria."
"INSP en Mexico publico en su base de datos que : a mayoría de las personas afirman que los hogares con menor nivel socioeconómico tienden a gastar más en productos
no saludables que las personas con mayores niveles socioeconómicos y que esto, entre otros determinantes, lleva a que un hogar presente cierta inseguridad alimentaria.
Usando la base de datos tendriamos que probar que lo que la INSP dice es cierto."

#Análisis descriptivo
summary(df.clean)
attach(df.clean)

# Medidas de tendencia central de Inseguridad Alimentaria
mean(IA)
median(IA)
Mode(IA)
# Medidas de dispersión de Inseguridad Alimentaria
var(IA)
sd(IA)

IQR(IA) #Dispersión alrededor a la mediana de Inseguridad Alimentaria
iqr = quantile(IA, probs = 0.75) - quantile(IA, probs = 0.25)
iqr
hist(IA,breaks=2 ,xaxp=c(0,1,1), main = "Histograma de Inseguridad Alimentaria", xlab = "Inseguridad Alimentaria")
boxplot(IA, horizontal = TRUE,main="Box plot de Inseguridad Alimentaria")

#########################Gasto de alimentos saludables#####################################
# Medidas de tendencia central de Inseguridad Alimentaria
mean(ln_als)
median(ln_als)
Mode(ln_als)
# Medidas de dispersión de Inseguridad Alimentaria
var(ln_als)
sd(ln_als)

IQR(ln_als) #Dispersión alrededor a la mediana de Inseguridad Alimentaria
iqr = quantile(ln_als, probs = 0.75) - quantile(ln_als, probs = 0.25)
iqr
hist(ln_als, main = "Histograma de Gasto de alimentos saludables", xlab = "Inseguridad Alimentaria")

"skewness(d$rs) #s > 0 Sesgo a la derecha
skewness(d$sim) #s = 0 Simétrica
skewness(d$ls) #s < 0 Sesgo a la izquierda

kurtosis(d$rs) #Leptocúrtica k > 3
kurtosis(d$sim) #Mesocúrtica k = 3
#Platocúrtica k < 3"
skewness(ln_als) #Sesgo a la izquierda
kurtosis(ln_als) #Leptocúrtica
#########################Gasto de alimentos no saludables#####################################
# Medidas de tendencia central de Inseguridad Alimentaria
mean(ln_alns)
median(ln_alns)
Mode(ln_alns)
# Medidas de dispersión de Inseguridad Alimentaria
var(ln_alns)
sd(ln_alns)

IQR(ln_alns) #Dispersión alrededor a la mediana de Inseguridad Alimentaria
iqr = quantile(ln_alns, probs = 0.75) - quantile(ln_alns, probs = 0.25)
iqr
hist(ln_alns, main = "Histograma de Gasto de alimentos no saludables", xlab = "Inseguridad Alimentaria")
boxplot(ln_alns, horizontal = TRUE,main="Box plot de Gasto de alimentos no saludables")
skewness(ln_alns) #Sesgo a la derecha
kurtosis(ln_alns) #Platocúrtica

#########################Nivel socioeconomico#####################################
# Medidas de tendencia central de Inseguridad Alimentaria
mean(nse5f)
median(nse5f)
Mode(nse5f)
# Medidas de dispersión de Inseguridad Alimentaria
var(nse5f)
sd(nse5f)

IQR(nse5f ) #Dispersión alrededor a la mediana de Inseguridad Alimentaria
iqr = quantile(nse5f , probs = 0.75) - quantile(nse5f , probs = 0.25)
iqr
hist(nse5f , main = "Histograma de Gasto del nivel socioeconomico", xlab = "Inseguridad Alimentaria")
boxplot(nse5f, horizontal = TRUE,main="Box plot del nivel socioeconomico")

#########################Ingresos extras#####################################
# Medidas de tendencia central de Inseguridad Alimentaria
mean(refin)
median(refin)
Mode(refin)
# Medidas de dispersión de Inseguridad Alimentaria
var(refin)
sd(refin)

IQR(refin ) #Dispersión alrededor a la mediana de Inseguridad Alimentaria
iqr = quantile(refin , probs = 0.75) - quantile(refin , probs = 0.25)
iqr
hist(refin , breaks=2 ,xaxp=c(0,1,1),main = "Histograma de Gasto de ingresos extras", xlab = "Inseguridad Alimentaria")

summary(df.clean)

gasto.graph.no.saludable <- ggplot(df.clean, aes(x = df.clean$nse5f, y=df.clean$ln_alns, color = factor(nse5f), size = df.clean$ln_alns)) + 
  geom_point(shape=1, alpha=1) 
gasto.graph.no.saludable

ia.graph <- ggplot(df.clean, aes(x = df.clean$IA, y=df.clean$nse5f, color = factor(nse5f), size = df.clean$ln_alns)) + 
  geom_point(shape=1, alpha=1) 
ia.graph
#############################################
probabilidad.IA=sum(df.clean$IA)/count(df.clean)
probabilidad.IA
porbabilidad.IA.dado.nivelbajo=sum(df.clean$IA[df.clean$nse5f==1] )/count(df.clean)
porbabilidad.IA.dado.nivelbajo
porbabilidad.IA.dado.nivelmediobajo=sum(df.clean$IA[df.clean$nse5f==1] )/count(df.clean)
porbabilidad.IA.dado.nivelmediobajo=sum(df.clean$IA[df.clean$nse5f==2] )/count(df.clean)
porbabilidad.IA.dado.nivelmedio=sum(df.clean$IA[df.clean$nse5f==3] )/count(df.clean)
porbabilidad.IA.dado.nivelmedioalto=sum(df.clean$IA[df.clean$nse5f==4] )/count(df.clean)
porbabilidad.IA.dado.nivelalto=sum(df.clean$IA[df.clean$nse5f==5] )/count(df.clean)
#########################################################
"Plantea hipótesis estadísticas y concluye sobre ellas para entender el problema en México"
" La mayoría de las personas afirman que los hogares con menor nivel socioeconómico tienden 
a gastar más en productos no saludables que las personas con mayores niveles socioeconómicos 
y que esto, entre otros determinantes, lleva a que un hogar presente cierta inseguridad alimentaria."
"Ho: promedio de gasto de productos no saludable del nivel socio economico bajo y medio bajo <= promedio de gasto no saludable del nivel medio, medio alto y alto
Ha: promedio de gasto de productos no saludable del nivel socio economico bajo y medio bajo > promedio de gasto no saludable del nivel medio, medio alto y alto"

"Primero hay que checar las varianzas de los grupos de nivel socio economico bajo(bajo y medio bajo) y alto(medio, medio alto y alto) si son iguales o diferentes
Ho: varianzas iguales
Ha: varianzas diferentes
"
var.test(df.clean$ln_alns[df.clean$nse5f==1 | df.clean$nse5f == 2], 
         df.clean$ln_alns[df.clean$nse5f==3 | df.clean$nse5f == 4 | df.clean$nse5f == 5], 
         ratio = 1, alternative = "two.sided")
"Con un p-value=2.2e-16 < 0.05, se concluye que se rechaz Ho. Entonces, las varianzas son diferentes."

t.test(x = df.clean$ln_alns[df.clean$nse5f==1 | df.clean$nse5f == 2], y = df.clean$ln_alns[df.clean$nse5f==3 | df.clean$nse5f == 4 | df.clean$nse5f == 5],
       alternative = "greater",
       mu = 0, var.equal = FALSE)
"Con un p-value = 1 > 0.05, no hay evidencia estadistica para rechazas Ho. Entonces, el gasto promedio de productos no saludables del nivel socioeconomico bajo(bajo y medio bajo) es menor o igual que los del nivel socioeconomico alto(medio, medio alto, y alto)."

#Hipotesis 2
"
Ho: promedio de la Inseguridad alimentaria nivel socioeconomico bajo <= promedio de la Inseguridad alimentaria nivel socioeconomico alto
Ha: promedio de la Inseguridad alimentaria nivel socioeconomico bajo > promedio de la Inseguridad alimentaria nivel socioeconomico alto
"
var.test(df.clean$IA[df.clean$nse5f==1 | df.clean$nse5f == 2], 
         df.clean$IA[df.clean$nse5f==3 | df.clean$nse5f == 4 | df.clean$nse5f == 5], 
         ratio = 1, alternative = "two.sided")
"Con un p-value=2.2e-16 < 0.05, se concluye que se rechaz Ho. Entonces, las varianzas son diferentes."

t.test(x = df.clean$IA[df.clean$nse5f==1 | df.clean$nse5f == 2], y = df.clean$IA[df.clean$nse5f==3 | df.clean$nse5f == 4 | df.clean$nse5f == 5],
       alternative = "greater",
       mu = 0, var.equal = FALSE)
"Con un p-value=2.2e-16 < 0.05, se rechaza Ho. Entonces la inseguridad alimentaria en el nivel socioeconomico bajo es mayor que el nivel socioeconomico alto"

"En conclusion, se concluye que el nivel socioeconomico bajo si tiene un promedio mayor de inseguridad alimentaria que el nivel alto. Pero, el nivel socio economico bajo no tiene un promedio mayor de gasto de productos no saludables que el nivel alto. 
Usnado esta base de datos, no se puede demostrar la afirmacion de la INSP de Mexico."

#"Modelo de regresion logistico e identificar los determinantes de la inseguridad alimentaria en Mexico"
library(dplyr)

summary(df.clean)

logistic.1 <- glm(IA ~ ln_als + ln_alns + nse5f + refin, 
                  data = df.clean, family = binomial)
summary(logistic.1)


pseudo_r2.1 <- (logistic.1$null.deviance - logistic.1$deviance)/logistic.1$null.deviance
pseudo_r2.1

#la variable del gasto de productos saludables no es relevante para el modelo logistico.
logistic.2 <- glm(IA ~ ln_alns + nse5f + refin, 
                  data = df.clean, family = binomial)
summary(logistic.2)
pseudo_r2.2 <- (logistic.2$null.deviance - logistic.2$deviance)/logistic.2$null.deviance
pseudo_r2.2


logistic.3 <- glm(IA ~ ln_alns + nse5f + refin + area + numpeho + edadjef + sexojef + añosedu , 
                data = df.clean, family = binomial)
summary(logistic.3)
pseudo_r2.3 <- (logistic.3$null.deviance - logistic.2$deviance)/logistic.2$null.deviance
pseudo_r2.3

logistic.4 <- glm(IA ~ ln_alns + nse5f + refin  + numpeho + sexojef + añosedu , 
                  data = df.clean, family = binomial)
summary(logistic.4)
pseudo_r2.4 <- (logistic.4$null.deviance - logistic.2$deviance)/logistic.2$null.deviance
pseudo_r2.4
#El logistic.4 tiene todas las variables significativas para el modelo (ln_alns, nse5f, refin, numpeho, sexojef y añosedu)