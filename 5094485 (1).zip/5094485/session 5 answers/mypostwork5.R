Postwork Sesión 5
OBJETIVO
Realizar inferencia estadística para extraer información de la muestra que sea contrastable con la población
REQUISITOS
Haber desarrollado los postworks anteriores
Cubrir los temas del prework
#Replicar los ejemplos de la sesión
#DESARROLLO
#El data frame iris contiene información recolectada por Anderson sobre 50 flores de 3 especies distintas (setosa, versicolor y virginca), incluyendo medidas en centímetros del largo y ancho del sépalo así como de los pétalos.
df <- iris
head(df)

#Utilizando pruebas de inferencia estadística, concluye si existe evidencia suficiente para concluir que los datos recolectados por Anderson están en línea con los nuevos estudios.
#Utiliza 99% de confianza para toda las pruebas, en cada caso realiza el planteamiento de hipótesis adecuado y concluye.

#Estudios recientes sobre las mismas especies muestran que:
  
#En promedio, el largo del sépalo de la especie setosa (Sepal.Length) 
#es igual a 5.7 cm
#Planteamiento de la hipotesis:
#Ho: promedio del largo del sepalo = 5.7
#Ha: promedio del largo del sepalo =! 5.7

t.test(x=df$Sepal.Length[df$Species=="setosa"], alternative = 'two.sided', mu=5.7)
#p-value = 2.2e-16 < 0.01
#Con un nivel de confianza de 99%, se rechaza la hipotesis nula. 
#Es decir, que el promedio del largo del sepalo es igual a 5.7 cm.


#En promedio, el ancho del pétalo de la especie virginica (Petal.Width) 
#es menor a 2.1 cm
#Planteamiento de la hipotesis
#Ho: promedio del ancho del petalo de virginica >= 2.1 
#Ha: promedio del ancho del petalo de virginica < 2.1
t.test(x=df$Petal.Width[df$Species=="virginica"], alternative = 'less', mu=2.1)
#p-value = 0.03132 > 0.01
#Con un nivel de confianza del 99%, no se rechaza Ho. Es decir,
#que el promedio del ancho del petalo de virginica es mayor o igual a 2.1 cm.


#En promedio, el largo del pétalo de la especie virgínica es 
#1.1 cm más grande que el promedio del largo del pétalo de la especie versicolor.

#Checar si las varianzas son iguales
#Planteamineto de hipotesis de varianzas
#Ho: varianza son iguales
#Ha: Varianzas son diferentes
var.test(df$Petal.Length[df$Species=="virginica"], 
         df$Petal.Length[df$Species=="versicolor"], 
         ratio = 1, alternative = "two.sided")
#con un p-value de 0.2637 > 0.01 se concluye que no hay evidencia estadistica para rechazar Ho. Es decir, las varianzas son iguales.
#Ho: el promedio del largo del petalo de virginica - promedio del largo de petalo de versicolor <= 1.1
#H1: el promedio del largo del petalo de virginica - promedio del largo de petalo de versicolor > 1.1
t.test(x = df$Petal.Length[df$Species=="virginica"], y = df$Petal.Length[df$Species=="versicolor"],
       alternative = "greater",
       mu = 1.1, var.equal = TRUE)
#p-value = 0.03202 > 0.01
#Con un nivel de confianza de 99%,no hay evidencia estadistica para rechazar Ho. Es decir,
# que el largo del petalo de virginica no es 1.1cm mas grande que el promedio del largo de petalo de versicolor.

#En promedio, no existe diferencia en el ancho del sépalo entre las 3 especies.

"Planteamiento de hipótesis:
Ho: el promedio del ancho de sepalo de setosa = promedio del ancho de sepalo de virginica = promedio del ancho de sepalo de versicolor
Ha: Al menos uno es diferente."
library(ggplot2)

boxplot(df$Sepal.Width)

boxplot(df$Sepal.Width ~ Species,
        data = df)

anova <- aov(df$Sepal.Width ~ Species,
             data = df)

summary(anova)
#p-value = <2e-16 < 0.01
#Con un valor de confianza de 99%, se rechaza Ho. Es decir, que por lo menos unos de los promedios de de ancho de sepalo es diferente. 
