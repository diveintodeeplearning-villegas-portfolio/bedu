"Reto 2. Inferencia sobre la media
OBJETIVO
Practicar la aplicación de técnicas estadísticas para inferir sobre la media de la población
REQUISITOS
Haber realizado el prework
Replicar los ejercicios de la sesión
DESARROLLO
Utilizando la base de datos de mpg (Fuel Economy Data) disponible en la librería de ggplot2, realiza los siguientes ejercicios indicando el juego de hipótesis y concluyendo de forma estadística a un nivel de confianza del 95%

library(ggplot2)
Con base en los datos, existe evidencia estadística para concluir que, en promedio, los coches producidos entre 1999 y 2008 podían recorrer más de 22.8 millas de carretera por galón (hwy)?

Con base en los datos, existe evidencia estadística para concluir que, en promedio, el desplazamiento del motor en litros (displ) para los coches producidos entre 1999 y 2008 era mayor o igual 3.7 litros?

Con base en los datos, existe evidencia estadística para concluir que, en promedio, los motores con 4 cilindros (cyl = 4) tienen un mayor rendimiento en millas de carretera por galón (hwy) que los motores con 6 cilindros (cyl = 6)"

library(ggplot2)

df <- mpg
head(df)
"Con base en los datos, existe evidencia estadística para concluir que, en promedio, 
los coches producidos entre 1999 y 2008 podían recorrer más de 22.8 millas de 
carretera por galón (hwy)?"
"Ho: promedio de coches producidos entre 1999 y 2008 <= 22.8
 Ha: promedio de coches producidos entre 1999 y 2008 > 22.8"
t.test(x = df$hwy , alternative = 'greater', mu = 22.8)
"p-value  = 0.05071 > 0.05
con un nivel de confianza de 95%, no hay evidencia estadistica para rechazar ho. Entonces,
el promedio de coches producidos entre 1999 y 2008 podian recorrer  22.8 millas de carretera por galon o menos"

"Con base en los datos, existe evidencia estadística para concluir que, en promedio, 
el desplazamiento del motor en litros (displ) para los coches producidos entre 1999 y 2008
era mayor o igual 3.7 litros?"
"Ho: el desplazamiento del motor en litros >= 3.7
 Ha: el desplazamiento del motor en litros < 3.7
"
t.test(x = df$displ , alternative = 'less', mu = 3.7)
"p-value = 0.0037 < 0.05
Con un 95% de nivel de confianza, se rechaza Ho. Entonces, se el desplazamiento del motor para los coches
producidos entre 1999 y 2008 era menor a 3.7 litros
"

"Con base en los datos, existe evidencia estadística para concluir que, en promedio, 
los motores con 4 cilindros (cyl = 4) tienen un mayor rendimiento en millas de carretera 
por galón (hwy) que los motores con 6 cilindros (cyl = 6)"
"Ho: rendimiento en millas de carretera por galon de los motroes con 4 cilindros <= rendimiento en millas de carretera por galn de los motores con 6 cilindros
Ho: rendimiento en millas de carretera por galon de los motroes con 4 cilindros > rendimiento en millas de carretera por galn de los motores con 6 cilindros"

head(df)
var.test(df$hwy[df$cyl==4], 
         df$hwy[df$cyl==6], 
         ratio = 1, alternative = "two.sided")
"con un p-value =0.0735>0.05 no hay evidencia estadistica para rechazar ho. son varianzas iguales"
t.test(x = df$hwy[df$cyl==4], 
       y = df$hwy[df$cyl==6],
       alternative = "two.sided",
       mu = 0, var.equal = TRUE)
#con un p-value 2.521e-16 < 0.05, se rechaza ho, entonces el redimiento en millas de carretera por galon
#de los motores con 4 cilinros es mayor que los de 6 cilindros